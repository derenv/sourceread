package derenvural.sourceread_prototype.ui.apps;

public enum redirectType {VIEW, ADD}

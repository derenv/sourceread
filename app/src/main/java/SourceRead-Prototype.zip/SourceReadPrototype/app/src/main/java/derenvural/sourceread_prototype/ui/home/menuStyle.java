package derenvural.sourceread_prototype.ui.home;

public enum menuStyle {
    VISIBLE, INVISIBLE
}
